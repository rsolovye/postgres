<?php
/**
 * Template Name: Страница:Театр
 *
 * Displays the contact page template.
 *
 * @package Theme Freesia
 * @subpackage Edge
 * @since Edge 1.0
 */
get_header();

?>
<style type="text/css">
* {
margin: 0;
padding: 0;
outline: 0;
}

#grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  grid-gap: 10px;
  grid-auto-rows: 100px;
  grid-template-areas: 
    "a a b b b c c c"
    "a a b b b c c c"
    "a a b b b c c c"
    "a a b b b c c c";
    align-self: start;
    align-items: baseline;
}


#logo {
grid-area:a;
justify-self:end;
}

#concept-text {
grid-area:b;
justify-self:center;
}


#theater-list {
    grid-area:theater-list;
    border-left: 1px solid #eee;
    border-right: 1px solid #eee;
    display: grid;
    grid-template-columns: 250px;
    grid-auto-row: 150px;
    padding: 3px;
    align-self:end;
    justify-self:end;
    border: 1px solid #000;

}

#theater-list h3 {
   background: #000;
   color: #C69f70;
   font: 'Lato', sans-serif;
   font-size: 15px;
   font-weight: bold;
   letter-spacing: 0.4em;
   padding: 15px;
   text-align: center;
   text-transform: uppercase;
   text-decoration: none;
}
#theater-list a{
      color: #333;
      font: 'Lato', sans-serif;
      font-size: 12px;
      font-weight: bold;
      letter-spacing: 0.2em;
      padding: 15px;
      text-align: center;
      text-transform: uppercase;
      text-decoration: none;
}
#sideba {
grid-area:c;
display:grid;
grid-template-columns: 250px;
grid-auto-rows: 100px;
grid-template-areas:
"theater-list";
align-items: baseline;
justify-self: start;
}

#theater-list a:hover{
 color: #C69f70;
}
#logo .img.resize{
padding: 2px;
border: 1px solid #000;
max.height: 215px;
width: auto;
}

img.resize{

}

#concept {
  grid-area: concept;
}

</style>
	
<main id="main> 
<div style="clear: both;"> </div>
<div id="grid">
<?php 
$theater_logo = get_field("theater_logo");
if ($theater_logo) {
echo '<div id="logo"><img class="resize" src="' .$theater_logo .'"></div>';
}
?>

<?php
echo '<div id="concept-text">';
$value = get_field("theater_concept");
if ($value) {
 echo $value;
}
echo '</div>';




echo '<div id="sideba">';
echo '<div id="theater-list">';
echo '<h3>Театры</h3>';
//$theater_parent_page_id = url_to_postid('http://teatrtogo.ru/teatry/');

$args = array(
    'post_type'      => 'page',
    'posts_per_page' => -1,
    'post_parent'    => 36,
    'order'          => 'ASC',
    'orderby'        => 'menu_order'
 );


$parent = new WP_Query( $args );


if ( $parent->have_posts() ) : 

while ( $parent->have_posts() ) : $parent->the_post(); 

// $page_template_slug =  get_page_template_slug( $parent->ID );

//if ($page_template_slug) {

//if (strcmp($page_template_slug, 'page-templates/theater-template.php') == 0)
 {


$theater_name = get_field("theater_name", $parent->ID);
$page_link = get_permalink($parent->ID);



echo '<a href="' .$page_link .'">' .$theater_name .'</a>';

//theater name and link
 //theater list
}//theate name
//}//theater slug
//slug
endwhile; endif;
wp_reset_postdata();
echo '</div></div>';

?>






</div> <!--grid-->
</main> <!-- #main -->



<?php
get_footer();
?>