<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'u0463351_wp');

/** Имя пользователя MySQL */
define('DB_USER', 'u0463351_wp');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'Sox10foxd3');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ';KUXUP&f`MLT[S-PH|b#_v_$bFAb5QwG+WS+/-TPSga^}s7I7&FMbiX68w56I,HU');
define('SECURE_AUTH_KEY',  'Al(xI;4>u_Q}/6O2qF!&LaMZ_r%R/*.?KD g?.xW,} J`wM(`oZsQ[l{4K2HyGQ.');
define('LOGGED_IN_KEY',    '2W.DYF!cS[@Yhw+8<#}$m`Y`TC9[a1:`*;-v2=Oo9_+Sz7[)v$r2<nnuvU;2&ye<');
define('NONCE_KEY',        '$F8ZE}RlxYFA4xz9>D2RYSu+Z/z4w.PEG@eXL7+J2b.>U-7+rVPB0P[L:eI=rY%b');
define('AUTH_SALT',        '<(kQ3N$>t^&V9on!k)y`0;]EXtZFk.EN_59XTYoQ8&ONC}O-d7L$Jpw:<Ak&V{lY');
define('SECURE_AUTH_SALT', 'Jt}I>uBd7%biba<hR);UM>TP9RC`,kJ%Dbss`g}Q)R*&K@I{QmmWn3w%fhn5~}0,');
define('LOGGED_IN_SALT',   'R36P5%}[+&v#NKzzcC8ijlFCIRmrSHvTx/SNB,W|9[`|?elo3f4K8qH{}X2U`,QT');
define('NONCE_SALT',       'W A#>kXWDxm^VyfWpz nt+eXfNhO]ywa,xx6fDY1Yc;o++=+^@RO5q3`5c6(nVT3');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
